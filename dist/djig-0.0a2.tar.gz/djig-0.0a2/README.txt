====
Djig
====

Djig is a minimalist, Digg-like news aggregator (old Digg, not new) for letting
users submit content.  Currently in a fairly alphaish state, not recommended
for use. 

License: Creative Commons Non-Commercial, 3.0
http://creativecommons.org/licenses/by-nc/3.0/
